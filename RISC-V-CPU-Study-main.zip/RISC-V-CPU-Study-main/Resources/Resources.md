Main Resources being referred to and followed in this study.

- eDX Course for Building a RISC-V CPU: https://www.edx.org/course/building-a-risc-v-cpu-core
- [[EECS-2011-62.pdf]] 
- https://web.engr.oregonstate.edu/~traylor/ece474/beamer_lectures/verilog_number_literals.pdf Representation of numbers in verilog.
- https://www.tutorialspoint.com/digital_circuits/digital_circuits_flip_flops.htm Flip Flops.
- https://www.chipverify.com/verilog/verilog-tutorial  Resource for Verilog syntax Description
